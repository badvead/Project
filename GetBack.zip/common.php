<?php


echo "

	<link rel=\"stylesheet\" href=\"css/bootstrap.css\">
	<link href=\"http://fonts.googleapis.com/css?family=Raleway:400,900,800,700,600,500,300,100,200\" rel=\"stylesheet\" type=\"text/css\">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
	<link rel=\"stylesheet\" href=\"https://netdna.bootstrapcdn.com/bootstrap/3.0.0-rc1/css/bootstrap.min.css\">
	<link rel=\"stylesheet\" href=\"css/survey.css\">
	<link rel=\"stylesheet\" href=\"css/common.css\">
   	<script type=\"text/javascript\" src=\"https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js\"></script>
   	<script type=\"text/javascript\" src=\"js/bootstrap.min.js\">
   	<script type=\"text/javascript\" src=\"js/jquery-1.7.2.min.js\">
    <script type=\"text/javascript\" src=\"https://netdna.bootstrapcdn.com/bootstrap/3.0.0-rc1/js/bootstrap.min.js\"></script>
    <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700|Josefin+Sans:100,400|Advent+Pro:400,100' rel='stylesheet' type='text/css'>

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>
	<script src=\"https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js\"></script>
	<![endif]-->
	<script src=\"https://ajax.googleapis.com/ajax/libs/angularjs/1.2.0/angular.min.js\"></script>
	<script type=\"text/javascript\" src=\"js/init.js\"></script>
	<script src=\"http://html5demos.com/h5utils.js\"></script>
	<script src=\"js/jquery.cookie.js\"></script>
	<link href='http://fonts.googleapis.com/css?family=Dosis:400,500,600|Lato:700,400italic,700italic|Iceland|Roboto+Slab:700,400,300,100|Luckiest+Guy|Geo:400,400italic' rel='stylesheet' type='text/css'>
";


?>