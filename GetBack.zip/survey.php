<?php
  
  include 'config.php';

  $tz_states = array (
    'America/Anchorage'=>array('AK'),
    'America/Boise'=>array('ID'),
    'America/Chicago'=>array('AL', 'AR', 'IL', 'IA', 'KS', 'LA', 'MN', 'MS', 'MO', 'NE', 'OK', 'SD', 'TN', 'TX', 'WI'),
    'America/Denver'=>array('CO', 'MT', 'NM', 'UT', 'WY'),
    'America/Detroit'=>array('MI'),
    'America/Indiana/Indianapolis'=>array('IN'),
    'America/Kentucky/Louisville'=>array('KY'),
    'America/Los_Angeles'=>array('CA', 'NV', 'OR', 'WA'),
    'America/New_York'=>array('CT', 'DE', 'FL', 'GA', 'ME', 'MD', 'MA', 'NH', 'NJ', 'NY', 'NC', 'OH', 'PA', 'RI', 'SC', 'VT', 'VA', 'DC', 'WV'),
    'America/North_Dakota/Center'=>array('ND'),
    'America/Phoenix'=>array('AZ'),
    'Pacific/Honolulu'=>array('HI'),
);

  if( $_GET["link"])
  {
     $link = $_GET["link"];

      $sql = mysql_query("SELECT * FROM links WHERE link='$link'") or die (mysql_error()."1");
      if(mysql_num_rows($sql) == 1){ 

        $row = mysql_fetch_array($sql) or die (mysql_error()."2");

        $link_id = $row['link_id'];
        $page_hits = $row['page_hits'];
        $surveys_taken = $row['surveys_taken'];

        $page_hits++;

        $query = "UPDATE links SET page_hits='$page_hits' WHERE link='$link' ";
        $sql = mysql_query($query) or die(mysql_error());


        $sql = mysql_query("SELECT * FROM business WHERE link_id='$link_id'") or die (mysql_error()."3");
        if(mysql_num_rows($sql) == 1){ 

          $row = mysql_fetch_array($sql) or die (mysql_error()."4");

          $business_id = $row['business_id'];
          $organization = $row['organization'];
          $address = $row['address'];
          $branding_url = $row['branding_url'];
          $question_unsorted = $row['question_array'];
          $question_array = explode(",",$question_unsorted);

          $survey_URL = $_SERVER['PHP_SELF']."?link=".$link;

          if(isset($_POST['submit'])){

            $surveys_taken++;

            $query = "UPDATE links SET surveys_taken='$surveys_taken' WHERE link='$link' ";
            $sql = mysql_query($query) or die(mysql_error()."5"); 

            $timezone = date_default_timezone_get();

            date_default_timezone_set('$timezone');
            $date = date('Y-m-d');
            $time = date('h:i:s a');

            $user_latitude = $_POST['latitude'];
            $user_longitude = $_POST['longitude'];

            $query = "INSERT INTO customers(customer_id, business_id, user_latitude, user_longitude, user_date, user_time, response_id) VALUES ('', '$business_id', '$user_latitude', '$user_longitude', '$date', '$time', '')"; 
            $sql = mysql_query($query) or die(mysql_error()."6");

            $sql = mysql_query("SELECT * FROM customers WHERE user_latitude='$user_latitude' AND user_longitude='$user_longitude' AND user_date='$date' AND user_time='$time'") or die (mysql_error()." 7");
            if(mysql_num_rows($sql) == 1){ 
              $row = mysql_fetch_array($sql) or die (mysql_error()."19");
              $customer_id = $row['customer_id'];
            }

            $length = count($question_array);

            $response_id = "";

            for ($i = 0; $i < $length; $i++) {
              
              $question_id = $question_array[$i];

              $sql = mysql_query("SELECT * FROM questions WHERE question_id='$question_id'") or die (mysql_error()."8");
              if(mysql_num_rows($sql) == 1){ 

                $row = mysql_fetch_array($sql) or die (mysql_error()."9");
                $frequency = $row['frequency'];

                $frequency++;

                $response = mysql_real_escape_string($_POST[$question_id]);

                $query = "UPDATE questions SET frequency='$frequency' WHERE question_id='$question_id'";
                $sql = mysql_query($query) or die(mysql_error()."10");

                $query = "INSERT INTO responses(response_id, question_id, customer_id, business_id, answer, response_date, response_time) VALUES ('','$question_id', '', '$business_id', '$response', '$date', '$time')"; 
                $sql = mysql_query($query) or die(mysql_error()."14");

                $query = "UPDATE responses SET customer_id='$customer_id' WHERE response_date='$date' AND response_time='$time' AND question_id='$question_id'";
                $sql = mysql_query($query) or die(mysql_error()."13");   

                $sql = mysql_query("SELECT * FROM responses WHERE response_date='$date' AND response_time='$time' AND question_id='$question_id'") or die (mysql_error()."8");
                if(mysql_num_rows($sql) == 1){ 

                  $row = mysql_fetch_array($sql) or die (mysql_error()."106"); 
                  $response_id = $row['response_id'];
                }    

              }

              if($i == 0) {
                $response_array = $response_id;
              } else {
                $response_array= $response_array.",".$response_id;
              }             

            }
            $query = "UPDATE customers SET response_id='$response_array' WHERE user_latitude='$user_latitude' AND user_longitude='$user_longitude' AND user_date='$date' AND user_time='$time'";
            $sql = mysql_query($query) or die(mysql_error()."128");

            echo "

            <!DOCTYPE html>
              <html>
                <head>
                  <?php include ('common.php');?>
                  <title>Survey for <?php echo $organization; ?> | GetBack</title>
                  <meta name=\"viewport\" content=\"width=device-width, user-scalable=no\">
                  <style>
                      body{
                        margin: 0px;
                        background-color: #29c6bc;
                        min-height: 100% !important;
                      }  

                      #thankswrapper{
                        height: 100%;
                        width: 100%;
                      }
                  </style>
                </head>
                <body>  
                    <div id=\"thankswrapper\">
                      Thanks for completeing our survey!</br>
                    <b>COUPON GOES HERE.</b>
                  </div>
                </body>
              </html>
              ";
            die ();
          }

        }

      }

  }


?>

<!DOCTYPE html>
<html>
  <head>
    <?php include ('common.php');?>
    <title>Survey for <?php echo $organization; ?> | GetBack</title>
    <meta name="viewport" content="width=device-width, user-scalable=no">
  </head>
  <body>  
    <div id="wrapper">

    <?php 
      echo "
          <div id=\"survey_header\">
            <div id=\"pagenav\"><span id=\"number\">1</span> of 5</div><div id=\"next\" class=\"navbut disabled\">NEXT</div>
          </div>

          <div id=\"survey_form\">
            <form action=\"".$survey_URL."\" method=\"post\">";
              

            $length = count($question_array);

            for ($i = 0; $i < $length; $i++) {
              $question_id = $question_array[$i];

              $x = $i+1;

              $sql = mysql_query("SELECT * FROM questions WHERE question_id='$question_id'") or die (mysql_error()."15");
              if(mysql_num_rows($sql) == 1){ 

                $row = mysql_fetch_array($sql) or die (mysql_error()."16");

                $question = $row['question'];

                echo "

                  <div id=\"".$x."\" class=\"survey_tab\">
                    <div class=\"survey_question\">".$question."</div>
                    <label id=\"yes\" class=\"survey_response\">
                      <input class=\"target\" type=\"radio\" name=\"".$question_id."\" value=\"yes\"/>yes
                    </label>
                    <label id=\"no\" class=\"survey_response\">
                      <input class=\"target\" type=\"radio\" name=\"".$question_id."\" value=\"no\"/>no
                    </label>
                  </div>


                ";

              }


            }
  
              

      echo "
              <input style=\"display: none\" type=\"text\" name=\"latitude\" value=\"\" id=\"latitude\" />
              <input style=\"display: none\" type=\"text\" name=\"longitude\" value=\"\" id=\"longitude\" />
              <p><input class=\"surveysubmit\" type=\"submit\" name=\"submit\" value=\"Give Feedback\" />
            </form>
          </div>
          
          <script>
          $(document).ready(function(){
            
            window.onload = function() {
              var userPos;
              navigator.geolocation.getCurrentPosition(function(position) {
                userPos = position;

                var latitude = userPos.coords.latitude;
                var longitude = userPos.coords.longitude;

                document.getElementById('latitude').setAttribute(\"value\", latitude);
                document.getElementById('longitude').setAttribute(\"value\", longitude);
              });
            };

          })
          </script>
          ";

    ?>
    </div>
  </body>
</html>