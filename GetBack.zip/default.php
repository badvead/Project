<!DOCTYPE html>
<head>
<title>Sign Up! | GetBack</title>
<style>

      #logo{
         position: absolute;
         height: 112px;
         width: 150px;
         top: 31px;
         margin-left: auto;
         margin-right: auto;
         left: 0;
         right: 0;
         z-index: 9999;
      }

      .LR-pwd-lr {
         display:none;
      }

      #tint{
        position: absolute;
        width: 500px;
        top: 600px;
        left: 0px;
        right: 0px;
        margin-left: auto;
        margin-right: auto;
        height: 300px:
        bottom: 0px;
        padding-bottom: 40px;
      }
</style>
<meta name="description" content="Inspire your Experience! Crowd-source your atmosphere, interactions and rewards at the places you frequent.">
<link rel="icon" href="favicon.ico" type="image/x-icon"/>
</head>
<body>
<!-- Begin LaunchRock Widget -->
<div id="logo"><img src="http://s12.postimg.org/6etw0m4t5/logo_with_type_01.png"></img></div>
<div id="lr-widget" rel="BHZ2MF2G"></div>
<script type="text/javascript" src="//ignition.launchrock.com/ignition-current.min.js"></script>
<!-- End LaunchRock Widget -->
<div id="tint">
<a class="twitter-timeline" href="https://twitter.com/GetBackAppTeam" data-widget-id="402694031265640448">Tweets by @GetBackAppTeam</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
</div>
</body>
</html>			